//
// Created by david on 27/03/2020.
//

#ifndef PROJECT2_GAME_IO_H
#define PROJECT2_GAME_IO_H

#endif //PROJECT2_GAME_IO_H

#include "game_Init.h"



void print_board(square board[BOARD_SIZE][BOARD_SIZE]);

void make_move(square board[BOARD_SIZE][BOARD_SIZE], player players[PLAYERS_NUM]);